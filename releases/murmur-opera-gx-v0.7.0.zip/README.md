# Murmur for Opera GX

This is the Opera GX package. Clicking **Open lyrics** closes Murmur's controls popup and opens a closeable reader over the right side of the active YouTube tab. It does not create or resize another Opera window. The reader follows song changes and displays the best available Genius match.

## Load Unpacked

1. Open `opera://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked** and choose this `packages/opera-gx` folder.
4. Refresh any YouTube tabs that were already open.

This manifest omits Chrome's `sidePanel` permission for Opera GX compatibility. The drawer is injected only on supported YouTube pages; reader content and automatic song-change behavior are otherwise shared with Chrome.
