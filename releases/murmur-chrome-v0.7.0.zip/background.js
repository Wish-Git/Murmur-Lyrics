const DEFAULT_SETTINGS = {
  enabled: false,
  autoOpen: true
};

let settingsCache = null;
const mediaByTab = new Map();
const resultsByTab = new Map();
const searchedByTab = new Map();
const trackKeyByTab = new Map();
const autoSearchTimerByTab = new Map();

chrome.runtime.onInstalled.addListener(() => {
  configureSidePanel().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  configureSidePanel().catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearAutoSearchTimer(tabId);
  mediaByTab.delete(tabId);
  resultsByTab.delete(tabId);
  searchedByTab.delete(tabId);
  trackKeyByTab.delete(tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then((response) => sendResponse({ ok: true, ...response }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleMessage(message, sender) {
  switch (message?.type) {
    case "MURMUR_MEDIA_STATE":
      return handleMediaState(message.payload, sender.tab);
    case "MURMUR_GET_STATE":
      return getUiState();
    case "MURMUR_GET_LYRICS_CONTEXT":
      return getLyricsContext(message.sourceTabId);
    case "MURMUR_UPDATE_SETTINGS":
      return updateSettings(message.patch || {});
    case "MURMUR_DETECT_ACTIVE":
      return detectActiveTab();
    case "MURMUR_SEARCH_ACTIVE":
      return searchActiveTab();
    case "MURMUR_GET_READER_URL":
      return { url: buildLyricsPanelUrl(sender.tab?.id, true) };
    case "MURMUR_SHOW_INLINE_READER":
      return controlInlineReader(message.sourceTabId, "MURMUR_SHOW_INLINE_READER");
    case "MURMUR_TOGGLE_INLINE_READER":
      return controlInlineReader(message.sourceTabId, "MURMUR_TOGGLE_INLINE_READER");
    case "MURMUR_HIDE_INLINE_READER":
      return controlInlineReader(message.sourceTabId, "MURMUR_HIDE_INLINE_READER");
    default:
      return {};
  }
}

async function configureSidePanel() {
  if (!chrome.sidePanel?.setOptions) {
    return;
  }

  await chrome.sidePanel.setOptions({
    path: "sidepanel.html",
    enabled: true
  });
}

async function getSettings() {
  if (settingsCache) {
    return settingsCache;
  }

  const stored = await storageGet(["settings"]);
  settingsCache = {
    enabled: Boolean(stored.settings?.enabled),
    autoOpen: stored.settings?.autoOpen !== false
  };
  return settingsCache;
}

async function updateSettings(patch) {
  const current = await getSettings();
  settingsCache = {
    enabled: typeof patch.enabled === "boolean" ? patch.enabled : current.enabled,
    autoOpen: typeof patch.autoOpen === "boolean" ? patch.autoOpen : current.autoOpen
  };
  await storageSet({ settings: settingsCache });

  if (settingsCache.enabled) {
    await detectActiveTab();
  }

  broadcastStateChanged();
  return { settings: settingsCache };
}

async function handleMediaState(payload, tab) {
  if (!tab?.id || !payload) {
    return {};
  }

  const stored = storeMediaState(payload, tab);

  const settings = await getSettings();
  if (shouldSearchMedia(stored.media, settings)) {
    queueAutoSearch(tab.id, stored.trackKey, stored.trackChanged ? 1200 : 450);
  }

  broadcastStateChanged();
  return {};
}

function storeMediaState(payload, tab) {
  const previous = mediaByTab.get(tab.id) || null;
  const previousKey = trackKeyByTab.get(tab.id) || getMediaTrackKey(previous);
  const trackKey = getMediaTrackKey(payload);
  const trackChanged = Boolean(previousKey && trackKey && previousKey !== trackKey);

  if (trackChanged) {
    clearTrackResults(tab.id);
  }

  const media = {
    ...payload,
    tabId: tab.id,
    windowId: tab.windowId,
    trackKey,
    trackChangedAt: trackChanged ? Date.now() : previous?.trackChangedAt || 0,
    receivedAt: Date.now()
  };
  mediaByTab.set(tab.id, media);
  if (trackKey) {
    trackKeyByTab.set(tab.id, trackKey);
  }

  return { media, trackKey, trackChanged };
}

function clearTrackResults(tabId) {
  clearAutoSearchTimer(tabId);
  resultsByTab.delete(tabId);
  searchedByTab.delete(tabId);
}

function clearAutoSearchTimer(tabId) {
  const timer = autoSearchTimerByTab.get(tabId);
  if (timer) {
    clearTimeout(timer);
    autoSearchTimerByTab.delete(tabId);
  }
}

function shouldSearchMedia(media, settings) {
  return Boolean(
    settings.enabled &&
    media?.playing &&
    media.title
  );
}

function queueAutoSearch(tabId, expectedTrackKey, delay) {
  clearAutoSearchTimer(tabId);
  const timer = setTimeout(async () => {
    autoSearchTimerByTab.delete(tabId);
    const media = mediaByTab.get(tabId);
    const settings = await getSettings();
    if (!media || !shouldSearchMedia(media, settings)) {
      return;
    }

    const latestTrackKey = getMediaTrackKey(media);
    if (expectedTrackKey && latestTrackKey && expectedTrackKey !== latestTrackKey) {
      queueAutoSearch(tabId, latestTrackKey, 450);
      return;
    }

    try {
      await searchAndMaybeOpen(tabId, true);
    } catch (error) {
      console.warn("Murmur automatic track update failed:", error);
    }
  }, delay);
  autoSearchTimerByTab.set(tabId, timer);
}

async function searchAndMaybeOpen(tabId, autoOpen) {
  const media = mediaByTab.get(tabId);
  if (!media) {
    return null;
  }

  const track = buildTrackIdentity(media);
  if (!track.query) {
    return null;
  }

  const trackKey = getMediaTrackKey(media) || track.query;
  const autoSignature = trackKey;
  if (autoOpen && searchedByTab.get(tabId) === autoSignature) {
    return resultsByTab.get(tabId) || null;
  }

  const requestId = `${tabId}:${Date.now()}:${normalizeForCompare(track.query)}`;
  const fallbackUrl = buildLyricsPanelUrl(tabId);
  const resultSet = [{
    title: track.title || "Lyrics",
    artist: track.artist || track.query,
    url: fallbackUrl,
    source: "Murmur reader / Genius",
    matchScore: 0
  }];
  const resultPayload = {
    provider: "genius",
    providerLabel: "Genius",
    query: track.query,
    track,
    trackKey,
    requestId,
    fallbackUrl,
    results: resultSet,
    updatedAt: Date.now()
  };

  resultsByTab.set(tabId, resultPayload);
  searchedByTab.set(tabId, autoSignature);

  const settings = await getSettings();
  if (autoOpen && settings.autoOpen && !chrome.sidePanel?.open) {
    await controlInlineReader(tabId, "MURMUR_SHOW_INLINE_READER");
  }

  broadcastStateChanged();
  return resultPayload;
}

async function detectActiveTab() {
  const tab = await getActiveTab();
  if (!tab?.id || !isYouTubeUrl(tab.url)) {
    return { activeTab: summarizeTab(tab), media: null };
  }

  let media = await requestMediaState(tab.id);
  if (!media) {
    try {
      await insertCSS(tab.id, "content/youtube-drawer.css").catch(() => {});
      await executeScript(tab.id, [
        "content/youtube-detector.js",
        "content/youtube-drawer.js"
      ]);
      media = await requestMediaState(tab.id);
    } catch (error) {
      console.warn("Murmur detection failed:", error);
    }
  }

  if (media) {
    storeMediaState(media, tab);
  }

  return {
    activeTab: summarizeTab(tab),
    media: mediaByTab.get(tab.id) || null,
    results: resultsByTab.get(tab.id) || null
  };
}

async function searchActiveTab() {
  const detection = await detectActiveTab();
  const tabId = detection.activeTab?.id;
  if (!tabId) {
    return detection;
  }

  const results = await searchAndMaybeOpen(tabId, false);
  return { ...detection, results };
}

async function getUiState() {
  const settings = await getSettings();
  const tab = await getActiveTab();
  const activeTab = summarizeTab(tab);
  const media = tab?.id ? mediaByTab.get(tab.id) || null : null;
  const results = tab?.id ? resultsByTab.get(tab.id) || null : null;

  return {
    extensionVersion: chrome.runtime.getManifest().version,
    settings,
    capabilities: {
      sidePanel: Boolean(chrome.sidePanel?.open),
      inlineReader: true
    },
    activeTab,
    media,
    results
  };
}

async function getLyricsContext(sourceTabId) {
  const requestedTabId = Number(sourceTabId);
  let tabId = Number.isInteger(requestedTabId) && requestedTabId > 0 ? requestedTabId : null;
  let tab = tabId ? await tabsGet(tabId).catch(() => null) : await getActiveTab().catch(() => null);

  if (!tabId && tab?.id && isYouTubeUrl(tab.url)) {
    tabId = tab.id;
  }

  if (!tabId) {
    const latest = [...mediaByTab.values()]
      .sort((left, right) => (right.receivedAt || 0) - (left.receivedAt || 0))[0];
    tabId = latest?.tabId || null;
    tab = tabId ? await tabsGet(tabId).catch(() => null) : null;
  }

  const media = tabId ? mediaByTab.get(tabId) || null : null;
  const results = tabId ? resultsByTab.get(tabId) || null : null;
  const track = results?.track || (media ? buildTrackIdentity(media) : null);

  return {
    extensionVersion: chrome.runtime.getManifest().version,
    sourceTabId: tabId,
    activeTab: summarizeTab(tab),
    settings: await getSettings(),
    media,
    results,
    track,
    trackKey: results?.trackKey || getMediaTrackKey(media)
  };
}

async function controlInlineReader(sourceTabId, type) {
  const requestedId = Number(sourceTabId);
  let tab = Number.isInteger(requestedId) && requestedId > 0
    ? await tabsGet(requestedId).catch(() => null)
    : await getActiveTab();

  if (!tab?.id || !isYouTubeUrl(tab.url)) {
    tab = await getActiveTab();
  }
  if (!tab?.id || !isYouTubeUrl(tab.url)) {
    throw new Error("Open a YouTube tab before opening lyrics.");
  }

  let response = await tabsSendMessage(tab.id, { type }).catch(() => null);
  if (!response?.ok) {
    if (type === "MURMUR_HIDE_INLINE_READER") {
      return { sourceTabId: tab.id, open: false };
    }
    await insertCSS(tab.id, "content/youtube-drawer.css").catch(() => {});
    await executeScript(tab.id, ["content/youtube-drawer.js"]);
    response = await tabsSendMessage(tab.id, { type });
  }
  if (!response?.ok) {
    throw new Error(response?.error || "Murmur could not open its YouTube drawer.");
  }

  return { sourceTabId: tab.id, open: Boolean(response.open) };
}

function buildTrackIdentity(media) {
  const parsed = parseArtistAndTitle(media.cleanTitle || media.title || "");
  const title = cleanTitle(parsed.title || media.cleanTitle || media.title || "");
  const artist = cleanArtist(parsed.artist || media.artist || media.channel || "");

  if (!title && !artist) {
    return { title: "", artist: "", query: "" };
  }

  const query = artist && title && !sameText(artist, title)
    ? `${artist} ${title}`
    : title || artist;
  return { title, artist, query: query.replace(/\s+/g, " ").trim() };
}

function buildLyricsPanelUrl(sourceTabId, embedded = false) {
  const url = new URL(chrome.runtime.getURL("sidepanel.html"));
  if (Number.isInteger(Number(sourceTabId)) && Number(sourceTabId) > 0) {
    url.searchParams.set("sourceTabId", String(sourceTabId));
  }
  if (embedded) {
    url.searchParams.set("embedded", "1");
  }
  return url.toString();
}

function getMediaTrackKey(media) {
  if (!media) {
    return "";
  }

  const track = buildTrackIdentity(media);
  const mediaId = String(media.mediaId || extractYouTubeMediaId(media.url) || "").trim();
  const identity = [normalizeForCompare(track.artist), normalizeForCompare(track.title)]
    .filter(Boolean)
    .join(":");
  return [mediaId, identity].filter(Boolean).join("|");
}

function extractYouTubeMediaId(value) {
  try {
    const url = new URL(value || "");
    if (url.pathname.startsWith("/shorts/")) {
      return url.pathname.split("/")[2] || "";
    }
    return url.searchParams.get("v") || "";
  } catch (error) {
    return "";
  }
}

function parseArtistAndTitle(rawTitle) {
  const title = String(rawTitle || "").replace(/\s+/g, " ").trim();
  const match = title.match(/^(.{2,80}?)\s(?:-|:|\u2013|\u2014)\s(.{2,120})$/);
  if (!match) {
    return { title };
  }

  const left = cleanArtist(match[1]);
  const right = cleanTitle(match[2]);
  if (!left || !right) {
    return { title };
  }

  return { artist: left, title: right };
}

function cleanTitle(value) {
  return String(value || "")
    .replace(/\s+-\s+YouTube$/i, "")
    .replace(/\s*\[[^\]]*(official|lyrics?|audio|video|visualizer|hd|4k)[^\]]*\]\s*/gi, " ")
    .replace(/\s*\([^)]*(official|lyrics?|audio|video|visualizer|hd|4k)[^)]*\)\s*/gi, " ")
    .replace(/\b(official music video|official video|lyric video|lyrics video|official audio|visualizer)\b/gi, " ")
    .replace(/\s+(?:ft\.?|feat\.?|featuring)\s+.+$/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanArtist(value) {
  return String(value || "")
    .replace(/\s*-\s*Topic$/i, "")
    .replace(/\bVEVO\b/g, "")
    .replace(/\s+(?:ft\.?|feat\.?|featuring)\s+.+$/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

function sameText(a, b) {
  return normalizeForCompare(a) === normalizeForCompare(b);
}

function normalizeForCompare(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function isYouTubeUrl(url) {
  try {
    const { hostname } = new URL(url || "");
    return ["www.youtube.com", "m.youtube.com", "music.youtube.com"].includes(hostname);
  } catch (error) {
    return false;
  }
}

function summarizeTab(tab) {
  if (!tab) {
    return null;
  }

  return {
    id: tab.id,
    windowId: tab.windowId,
    title: tab.title,
    url: tab.url,
    isYouTube: isYouTubeUrl(tab.url)
  };
}

function broadcastStateChanged() {
  try {
    const maybePromise = chrome.runtime.sendMessage({ type: "MURMUR_STATE_CHANGED" });
    if (maybePromise?.catch) {
      maybePromise.catch(() => {});
    }
  } catch (error) {
    // There may be no extension UI listening.
  }
}

async function getActiveTab() {
  const [focusedTab] = await tabsQuery({ active: true, lastFocusedWindow: true });
  if (isYouTubeUrl(focusedTab?.url)) {
    return focusedTab;
  }

  const activeYouTubeTabs = await tabsQuery({
    active: true,
    url: [
      "https://www.youtube.com/*",
      "https://m.youtube.com/*",
      "https://music.youtube.com/*"
    ]
  });
  activeYouTubeTabs.sort((left, right) => (right.lastAccessed || 0) - (left.lastAccessed || 0));
  return activeYouTubeTabs[0] || focusedTab || null;
}

function requestMediaState(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: "MURMUR_COLLECT_NOW" }, (response) => {
      if (chrome.runtime.lastError || !response?.ok) {
        resolve(null);
        return;
      }
      resolve(response.payload || null);
    });
  });
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

function tabsQuery(queryInfo) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(queryInfo, (tabs) => {
      const error = chrome.runtime.lastError;
      error ? reject(error) : resolve(tabs);
    });
  });
}

function tabsGet(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabs.get(tabId, (tab) => {
      const error = chrome.runtime.lastError;
      error ? reject(error) : resolve(tab);
    });
  });
}

function tabsSendMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError;
      error ? reject(error) : resolve(response || {});
    });
  });
}

function executeScript(tabId, files) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript({
      target: { tabId },
      files: Array.isArray(files) ? files : [files]
    }, (result) => {
      const error = chrome.runtime.lastError;
      error ? reject(error) : resolve(result);
    });
  });
}

function insertCSS(tabId, file) {
  return new Promise((resolve, reject) => {
    chrome.scripting.insertCSS({ target: { tabId }, files: [file] }, () => {
      const error = chrome.runtime.lastError;
      error ? reject(error) : resolve();
    });
  });
}
