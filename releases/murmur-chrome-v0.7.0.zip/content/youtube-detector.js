(() => {
  if (window.__murmurLoaded) {
    window.__murmurSendState?.();
    return;
  }

  window.__murmurLoaded = true;

  let lastSignature = "";
  let lastSentAt = 0;
  let boundVideo = null;
  const burstTimers = new Set();
  const videoEvents = ["play", "playing", "loadedmetadata", "durationchange", "emptied", "ended"];

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "MURMUR_COLLECT_NOW") {
      return false;
    }

    const payload = collectMediaState();
    sendResponse({ ok: true, payload });
    sendState(payload, true);
    return true;
  });

  window.__murmurSendState = () => sendState(collectMediaState(), true);

  const observer = new MutationObserver(() => {
    bindVideoEvents();
    scheduleSend();
  });
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    characterData: true
  });

  ["yt-navigate-start", "yt-navigate-finish", "yt-page-data-updated", "yt-player-updated"]
    .forEach((eventName) => window.addEventListener(eventName, scheduleTrackChangeBurst));
  document.addEventListener("visibilitychange", scheduleTrackChangeBurst);

  setInterval(() => {
    bindVideoEvents();
    sendState(collectMediaState());
  }, 1000);
  bindVideoEvents();
  scheduleTrackChangeBurst();

  function bindVideoEvents() {
    const video = document.querySelector("video");
    if (video === boundVideo) {
      return;
    }

    if (boundVideo) {
      videoEvents.forEach((eventName) => boundVideo.removeEventListener(eventName, scheduleTrackChangeBurst));
    }

    boundVideo = video;
    if (boundVideo) {
      videoEvents.forEach((eventName) => boundVideo.addEventListener(eventName, scheduleTrackChangeBurst));
    }
  }

  function scheduleTrackChangeBurst() {
    for (const timer of burstTimers) {
      window.clearTimeout(timer);
    }
    burstTimers.clear();

    [50, 350, 900, 1600].forEach((delay, index) => {
      const timer = window.setTimeout(() => {
        burstTimers.delete(timer);
        bindVideoEvents();
        scheduleSend(index === 0);
      }, delay);
      burstTimers.add(timer);
    });
  }

  function scheduleSend(force = false) {
    window.clearTimeout(scheduleSend.timer);
    scheduleSend.timer = window.setTimeout(() => {
      sendState(collectMediaState(), force);
    }, force ? 50 : 250);
  }

  function sendState(payload, force = false) {
    const signature = [
      payload.url,
      payload.mediaId,
      payload.title,
      payload.artist,
      payload.channel,
      payload.playing,
      Math.floor((payload.duration || 0) / 10)
    ].join("|");

    const now = Date.now();
    if (!force && signature === lastSignature && now - lastSentAt < 8000) {
      return;
    }

    lastSignature = signature;
    lastSentAt = now;

    try {
      chrome.runtime.sendMessage({ type: "MURMUR_MEDIA_STATE", payload }, () => {
        chrome.runtime.lastError;
      });
    } catch (error) {
      // The extension can be reloaded while YouTube keeps the content script alive.
    }
  }

  function collectMediaState() {
    const video = document.querySelector("video");
    const music = location.hostname === "music.youtube.com";
    const sessionMetadata = navigator.mediaSession?.metadata;
    const title = (music ? getYouTubeMusicTitle() : getYouTubeTitle()) || sessionMetadata?.title || "";
    const artist = (music ? getYouTubeMusicArtist() : "") || sessionMetadata?.artist || "";
    const channel = music ? artist : getYouTubeChannel();
    const cleanTitle = cleanVideoTitle(title || document.title);
    const playback = getPlaybackState(video);

    return {
      url: location.href,
      mediaId: getMediaId(),
      title: title || document.title || "",
      cleanTitle,
      artist,
      channel,
      playing: playback.playing,
      audible: playback.audible,
      currentTime: playback.currentTime,
      duration: playback.duration,
      observedAt: Date.now()
    };
  }

  function getPlaybackState(video) {
    if (!video) {
      return {
        playing: false,
        audible: false,
        currentTime: 0,
        duration: 0
      };
    }

    return {
      playing: !video.paused && !video.ended && video.readyState >= 2,
      audible: !video.muted && video.volume > 0,
      currentTime: Number.isFinite(video.currentTime) ? video.currentTime : 0,
      duration: Number.isFinite(video.duration) ? video.duration : 0
    };
  }

  function getYouTubeMusicTitle() {
    return firstText([
      "ytmusic-player-bar .title",
      "ytmusic-player-page .title",
      "yt-formatted-string.title"
    ]);
  }

  function getYouTubeMusicArtist() {
    const byline = firstText([
      "ytmusic-player-bar .byline",
      "ytmusic-player-page .byline",
      ".subtitle.ytmusic-player-bar"
    ]);

    return byline.split(/ \u2022 | - /)[0]?.trim() || byline;
  }

  function getYouTubeTitle() {
    return firstText([
      "ytd-watch-metadata h1 yt-formatted-string",
      "ytd-watch-metadata h1",
      "#title h1 yt-formatted-string",
      "h1.title yt-formatted-string",
      "meta[itemprop='name']"
    ], "content") || cleanVideoTitle(document.title);
  }

  function getYouTubeChannel() {
    return firstText([
      "ytd-watch-metadata ytd-video-owner-renderer #channel-name a",
      "ytd-watch-metadata #owner #channel-name a",
      "#upload-info #channel-name a",
      "#owner-name a",
      "link[itemprop='name']"
    ], "content");
  }

  function firstText(selectors, attr) {
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (!node) {
        continue;
      }

      const value = (attr ? node.getAttribute(attr) : "") || node.textContent;
      if (value && value.trim()) {
        return value.replace(/\s+/g, " ").trim();
      }
    }

    return "";
  }

  function getMediaId() {
    try {
      const url = new URL(location.href);
      if (url.pathname.startsWith("/shorts/")) {
        return url.pathname.split("/")[2] || "";
      }
      return url.searchParams.get("v") || "";
    } catch (error) {
      return "";
    }
  }

  function cleanVideoTitle(value) {
    return String(value || "")
      .replace(/^\(\d+\)\s*/, "")
      .replace(/\s+-\s+YouTube$/i, "")
      .replace(/\s+/g, " ")
      .trim();
  }

})();
