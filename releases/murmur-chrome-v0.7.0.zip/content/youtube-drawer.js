(() => {
  if (window.__murmurDrawerLoaded) {
    return;
  }

  window.__murmurDrawerLoaded = true;

  let drawer = null;
  let frame = null;
  let status = null;
  let readerUrlPromise = null;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "MURMUR_SHOW_INLINE_READER") {
      showDrawer()
        .then(() => sendResponse({ ok: true, open: true }))
        .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
      return true;
    }

    if (message?.type === "MURMUR_TOGGLE_INLINE_READER") {
      toggleDrawer()
        .then((open) => sendResponse({ ok: true, open }))
        .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
      return true;
    }

    if (message?.type === "MURMUR_HIDE_INLINE_READER") {
      hideDrawer();
      sendResponse({ ok: true, open: false });
      return false;
    }

    return false;
  });

  window.addEventListener("message", (event) => {
    if (
      event.source === frame?.contentWindow &&
      event.data?.source === "murmur-reader" &&
      event.data?.type === "MURMUR_CLOSE_INLINE_READER"
    ) {
      hideDrawer();
    }
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && isDrawerOpen()) {
      hideDrawer();
    }
  });

  async function showDrawer() {
    await ensureDrawer();
    drawer.classList.add("murmur-is-open");
    drawer.setAttribute("aria-hidden", "false");
  }

  async function toggleDrawer() {
    await ensureDrawer();
    if (isDrawerOpen()) {
      hideDrawer();
      return false;
    }

    drawer.classList.add("murmur-is-open");
    drawer.setAttribute("aria-hidden", "false");
    return true;
  }

  function hideDrawer() {
    if (!drawer) {
      return;
    }

    drawer.classList.remove("murmur-is-open");
    drawer.setAttribute("aria-hidden", "true");
  }

  function isDrawerOpen() {
    return Boolean(drawer?.classList.contains("murmur-is-open"));
  }

  async function ensureDrawer() {
    if (drawer?.isConnected) {
      return;
    }

    drawer = document.createElement("aside");
    drawer.id = "murmur-reader-drawer";
    drawer.setAttribute("aria-label", "Murmur lyrics");
    drawer.setAttribute("aria-hidden", "true");

    status = document.createElement("div");
    status.className = "murmur-drawer-status";
    status.textContent = "Opening Murmur...";

    frame = document.createElement("iframe");
    frame.className = "murmur-drawer-frame";
    frame.title = "Murmur lyrics";
    frame.addEventListener("load", () => {
      if (frame.src && frame.src !== "about:blank") {
        drawer.classList.add("murmur-is-ready");
      }
    });

    drawer.replaceChildren(status, frame);
    document.documentElement.append(drawer);

    try {
      frame.src = await getReaderUrl();
    } catch (error) {
      status.textContent = "Murmur could not open here. Refresh this YouTube tab and try again.";
      throw error;
    }
  }

  function getReaderUrl() {
    if (readerUrlPromise) {
      return readerUrlPromise;
    }

    readerUrlPromise = new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: "MURMUR_GET_READER_URL" }, (response) => {
        const error = chrome.runtime.lastError;
        if (error || response?.ok === false || !response?.url) {
          readerUrlPromise = null;
          reject(new Error(error?.message || response?.error || "Reader URL unavailable"));
          return;
        }

        resolve(response.url);
      });
    });

    return readerUrlPromise;
  }
})();
