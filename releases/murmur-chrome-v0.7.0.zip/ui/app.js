const surface = document.body.dataset.surface || "popup";
const elements = {
  surfaceLabel: document.getElementById("surfaceLabel"),
  statusPanel: document.getElementById("statusPanel"),
  enabledLabel: document.getElementById("enabledLabel"),
  statusText: document.getElementById("statusText"),
  enabledToggle: document.getElementById("enabledToggle"),
  autoOpenToggle: document.getElementById("autoOpenToggle"),
  trackTitle: document.getElementById("trackTitle"),
  trackMeta: document.getElementById("trackMeta"),
  detectButton: document.getElementById("detectButton"),
  openLyricsButton: document.getElementById("openLyricsButton")
};

let state = null;
let refreshTimer = null;

init().catch((error) => renderError(error.message || String(error)));

async function init() {
  bindEvents();
  await refresh(true);
  refreshTimer = window.setInterval(() => refresh(false).catch(() => {}), 3000);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "MURMUR_STATE_CHANGED") {
      refresh(false).catch(() => {});
    }
  });
}

function bindEvents() {
  elements.enabledToggle.addEventListener("change", async () => {
    const enabled = elements.enabledToggle.checked;
    const nativePanel = enabled ? openNativeSidePanel().catch(() => false) : Promise.resolve(false);

    await send({ type: "MURMUR_UPDATE_SETTINGS", patch: { enabled } });
    await refresh(true);

    if (!enabled) {
      await send({
        type: "MURMUR_HIDE_INLINE_READER",
        sourceTabId: state?.activeTab?.id
      }).catch(() => {});
      return;
    }

    const openedNativePanel = await nativePanel;
    if (!openedNativePanel && state?.activeTab?.isYouTube) {
      await send({
        type: "MURMUR_SHOW_INLINE_READER",
        sourceTabId: state.activeTab.id
      });
    }
    window.close();
  });

  elements.autoOpenToggle.addEventListener("change", async () => {
    await send({
      type: "MURMUR_UPDATE_SETTINGS",
      patch: { autoOpen: elements.autoOpenToggle.checked }
    });
    await refresh(false);
  });

  elements.detectButton.addEventListener("click", async () => {
    elements.detectButton.disabled = true;
    await send({ type: "MURMUR_DETECT_ACTIVE" });
    await send({ type: "MURMUR_SEARCH_ACTIVE" });
    await refresh(false);
    elements.detectButton.disabled = false;
  });

  elements.openLyricsButton.addEventListener("click", async () => {
    elements.openLyricsButton.disabled = true;
    const nativePanel = openNativeSidePanel().catch(() => false);
    await send({ type: "MURMUR_SEARCH_ACTIVE" });
    const openedNativePanel = await nativePanel;
    if (!openedNativePanel) {
      await send({
        type: "MURMUR_TOGGLE_INLINE_READER",
        sourceTabId: state?.activeTab?.id
      });
    }
    window.close();
  });
}

async function refresh(forceDetect) {
  if (forceDetect) {
    await send({ type: "MURMUR_DETECT_ACTIVE" });
  }

  state = await send({ type: "MURMUR_GET_STATE" });
  render();
}

function render() {
  if (!state) {
    return;
  }

  const { settings, activeTab, media } = state;
  const surfaceName = surface === "sidepanel" ? "Side panel" : "Popup";
  const version = state.extensionVersion || chrome.runtime.getManifest().version;
  elements.surfaceLabel.textContent = `${surfaceName} / v${version}`;
  elements.enabledToggle.checked = Boolean(settings.enabled);
  elements.autoOpenToggle.checked = Boolean(settings.autoOpen);
  elements.enabledLabel.textContent = settings.enabled ? "Murmur is on" : "Murmur is off";
  elements.statusPanel.classList.toggle("is-enabled", Boolean(settings.enabled));

  if (!activeTab?.isYouTube) {
    elements.statusText.textContent = "Open a YouTube tab to begin.";
  } else if (!media) {
    elements.statusText.textContent = "Ready to check this YouTube tab.";
  } else if (!media.playing) {
    elements.statusText.textContent = "YouTube is open, playback is paused.";
  } else {
    elements.statusText.textContent = "Song detected.";
  }

  renderTrack(media);
  const canUseReader = Boolean(activeTab?.isYouTube && media?.title);
  elements.openLyricsButton.disabled = !canUseReader;
  elements.detectButton.disabled = !activeTab?.isYouTube;
}

function renderTrack(media) {
  if (!media?.title) {
    elements.trackTitle.textContent = "No track detected";
    elements.trackMeta.textContent = "Open a YouTube tab and start playback.";
    return;
  }

  elements.trackTitle.textContent = media.cleanTitle || media.title;
  elements.trackMeta.textContent = [media.artist || media.channel, media.playing ? "Playing" : "Paused"]
    .filter(Boolean)
    .join(" / ");
}

async function openNativeSidePanel() {
  if (!chrome.sidePanel?.open) {
    return false;
  }

  try {
    const tab = state?.activeTab;
    await chrome.sidePanel.open({ windowId: tab?.windowId ?? chrome.windows?.WINDOW_ID_CURRENT ?? -2 });
    if (chrome.sidePanel.setOptions) {
      await chrome.sidePanel.setOptions({ path: "sidepanel.html", enabled: true });
    }
    return true;
  } catch (error) {
    return false;
  }
}

function send(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(error);
        return;
      }
      if (response?.ok === false) {
        reject(new Error(response.error || "Extension request failed"));
        return;
      }
      resolve(response || {});
    });
  });
}

function renderError(message) {
  elements.statusText.textContent = message;
  elements.statusText.style.color = "var(--danger)";
}

window.addEventListener("unload", () => {
  if (refreshTimer) {
    window.clearInterval(refreshTimer);
  }
});
