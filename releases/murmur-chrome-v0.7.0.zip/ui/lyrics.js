const {
  buildFallbackTrackKey,
  isExcludedLyricsElement,
  isGeniusSongHit,
  normalizeGeniusLyricsUrl,
  normalizeLyricsText,
  rankCandidates,
  selectBestCandidate
} = MurmurLyricsCore;
const readerParams = new URLSearchParams(location.search);
const sourceTabValue = readerParams.get("sourceTabId");
const sourceTabParam = Number(sourceTabValue);
const requestedSourceTabId = sourceTabValue && Number.isInteger(sourceTabParam) && sourceTabParam > 0
  ? sourceTabParam
  : null;
const embeddedReader = readerParams.get("embedded") === "1";

const elements = {
  trackTitle: document.getElementById("readerTrackTitle"),
  trackArtist: document.getElementById("readerTrackArtist"),
  emptyState: document.getElementById("emptyState"),
  loadingState: document.getElementById("loadingState"),
  loadingTitle: document.getElementById("loadingTitle"),
  loadingText: document.getElementById("loadingText"),
  errorState: document.getElementById("errorState"),
  errorText: document.getElementById("errorText"),
  retryButton: document.getElementById("retryButton"),
  lyricsSection: document.getElementById("lyricsSection"),
  lyricsContent: document.getElementById("lyricsContent"),
  matchLabel: document.getElementById("matchLabel"),
  sourceLink: document.getElementById("sourceLink"),
  closeButton: document.getElementById("closeReaderButton"),
  version: document.getElementById("readerVersion")
};

let currentContext = null;
let currentTrackKey = "";
let activeRequest = null;
let requestToken = 0;
let refreshTimer = null;

if (embeddedReader) {
  document.body.classList.add("embedded-reader");
  elements.closeButton.hidden = false;
} else if (requestedSourceTabId) {
  document.body.classList.add("standalone-reader");
}

init().catch((error) => showError(readableError(error)));

async function init() {
  elements.retryButton.addEventListener("click", () => refreshContext(true));
  elements.closeButton.addEventListener("click", closeEmbeddedReader);
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && embeddedReader) {
      closeEmbeddedReader();
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "MURMUR_STATE_CHANGED") {
      refreshContext(false).catch(() => {});
    }
  });

  await refreshContext(true);
  refreshTimer = window.setInterval(() => refreshContext(false).catch(() => {}), 2500);
}

async function refreshContext(force) {
  const context = await send({
    type: "MURMUR_GET_LYRICS_CONTEXT",
    sourceTabId: requestedSourceTabId
  });
  currentContext = context;
  elements.version.textContent = `Murmur v${context.extensionVersion || chrome.runtime.getManifest().version}`;

  const track = context.track;
  const trackKey = context.trackKey || buildFallbackTrackKey(track);
  renderTrack(track, context.media);

  if (!track?.title && !track?.query) {
    currentTrackKey = "";
    cancelActiveRequest();
    showState("empty");
    return;
  }

  if (!force && trackKey && trackKey === currentTrackKey) {
    return;
  }

  currentTrackKey = trackKey;
  await loadLyrics(track, trackKey);
}

async function loadLyrics(track, expectedTrackKey) {
  cancelActiveRequest();
  const controller = new AbortController();
  const token = ++requestToken;
  activeRequest = controller;
  showLoading("Finding lyrics", "Checking for an exact title and artist match.");

  try {
    const candidate = await findGeniusCandidate(track, controller.signal);
    ensureCurrentRequest(token, expectedTrackKey);
    showLoading("Formatting lyrics", "Preparing a clean Murmur reader view.");

    const lyrics = await scrapeGeniusLyrics(candidate.url, controller.signal);
    ensureCurrentRequest(token, expectedTrackKey);
    renderLyrics(candidate, lyrics);
  } catch (error) {
    if (error?.name === "AbortError" || token !== requestToken) {
      return;
    }
    showError(readableError(error));
  } finally {
    if (token === requestToken) {
      activeRequest = null;
    }
  }
}

async function findGeniusCandidate(track, signal) {
  const candidates = [];
  const searchUrl = `https://genius.com/search?q=${encodeURIComponent(track.query || `${track.artist || ""} ${track.title || ""}`.trim())}`;

  try {
    const response = await fetch(searchUrl, {
      cache: "no-store",
      credentials: "omit",
      signal
    });
    if (response.ok) {
      const html = await response.text();
      candidates.push(...parseGeniusSearchPage(html));
    }
  } catch (error) {
    if (error?.name === "AbortError") {
      throw error;
    }
  }

  let ranked = rankCandidates(track, candidates);
  if (!ranked[0]) {
    try {
      candidates.push(...await fetchGeniusSearchApi(track, signal));
      ranked = rankCandidates(track, candidates);
    } catch (error) {
      if (error?.name === "AbortError" || !candidates.length) {
        throw error;
      }
    }
  }

  const best = ranked[0] || selectBestCandidate(track, candidates);
  if (!best) {
    throw new Error("Genius did not return a usable result for this song.");
  }

  return best;
}

function parseGeniusSearchPage(html) {
  const document = new DOMParser().parseFromString(html, "text/html");
  return [...document.querySelectorAll("mini-song-card a.mini_card, a.mini_card[href*='genius.com']")]
    .map((link) => ({
      title: link.querySelector(".mini_card-title")?.textContent?.trim() || "",
      artist: link.querySelector(".mini_card-subtitle")?.textContent?.trim() || "",
      url: normalizeGeniusLyricsUrl(link.getAttribute("href") || link.href)
    }))
    .filter((candidate) => candidate.title && candidate.url);
}

async function fetchGeniusSearchApi(track, signal) {
  const query = track.query || `${track.artist || ""} ${track.title || ""}`.trim();
  const response = await fetch(`https://genius.com/api/search/multi?q=${encodeURIComponent(query)}`, {
    cache: "no-store",
    credentials: "omit",
    signal
  });

  if (!response.ok) {
    throw new Error(`Genius search returned ${response.status}.`);
  }

  const payload = await response.json();
  const sections = Array.isArray(payload?.response?.sections) ? payload.response.sections : [];
  return sections
    .flatMap((section) => Array.isArray(section?.hits) ? section.hits : [])
    .filter(isGeniusSongHit)
    .map((hit) => hit.result)
    .map((result) => ({
      title: result.title || result.title_with_featured || "",
      artist: result.primary_artist?.name || result.artist_names || "",
      url: normalizeGeniusLyricsUrl(result.url)
    }))
    .filter((candidate) => candidate.title && candidate.url);
}

async function scrapeGeniusLyrics(url, signal) {
  const safeUrl = normalizeGeniusLyricsUrl(url);
  if (!safeUrl) {
    throw new Error("Genius returned an invalid lyrics address.");
  }

  const response = await fetch(safeUrl, {
    cache: "no-store",
    credentials: "omit",
    signal
  });
  if (!response.ok) {
    throw new Error(`The Genius lyrics page returned ${response.status}.`);
  }

  const html = await response.text();
  const document = new DOMParser().parseFromString(html, "text/html");
  const containers = [...document.querySelectorAll('[data-lyrics-container="true"]')];
  if (!containers.length) {
    const legacy = document.querySelector(".lyrics");
    if (legacy) {
      containers.push(legacy);
    }
  }

  const lyrics = normalizeLyricsText(containers.map(serializeLyricsNode).join("\n\n"));
  if (lyrics.length < 24) {
    throw new Error("Genius did not return a readable lyrics section.");
  }

  return lyrics;
}

function serializeLyricsNode(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    return node.nodeValue || "";
  }
  if (node.nodeType !== Node.ELEMENT_NODE) {
    return "";
  }

  const tagName = node.tagName.toLowerCase();
  if (isExcludedLyricsElement(node)) {
    return "";
  }
  if (tagName === "br") {
    return "\n";
  }

  const text = [...node.childNodes].map(serializeLyricsNode).join("");
  return ["div", "p", "li"].includes(tagName) ? `${text}\n` : text;
}

function renderTrack(track, media) {
  const title = track?.title || media?.cleanTitle || media?.title || "Waiting for a song";
  const artist = track?.artist || media?.artist || media?.channel || "YouTube";
  elements.trackTitle.textContent = title;
  elements.trackArtist.textContent = artist;
  document.title = track?.title ? `${track.title} / Murmur` : "Murmur lyrics";
}

function renderLyrics(candidate, lyrics) {
  const fragment = document.createDocumentFragment();
  let previousWasGap = false;

  for (const line of lyrics.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) {
      if (!previousWasGap && fragment.childNodes.length) {
        const gap = document.createElement("div");
        gap.className = "lyrics-gap";
        gap.setAttribute("aria-hidden", "true");
        fragment.append(gap);
      }
      previousWasGap = true;
      continue;
    }

    const element = document.createElement(/^\[[^\]]+\]$/.test(trimmed) ? "div" : "p");
    element.className = element.tagName === "DIV" ? "lyrics-section-label" : "lyrics-line";
    element.textContent = trimmed;
    fragment.append(element);
    previousWasGap = false;
  }

  elements.lyricsContent.replaceChildren(fragment);
  elements.matchLabel.textContent = [candidate.title, candidate.artist].filter(Boolean).join(" / ");
  elements.sourceLink.href = candidate.url;
  showState("lyrics");
}

function showLoading(title, text) {
  elements.loadingTitle.textContent = title;
  elements.loadingText.textContent = text;
  showState("loading");
}

function showError(message) {
  elements.errorText.textContent = message;
  showState("error");
}

function showState(state) {
  elements.emptyState.hidden = state !== "empty";
  elements.loadingState.hidden = state !== "loading";
  elements.errorState.hidden = state !== "error";
  elements.lyricsSection.hidden = state !== "lyrics";
}

function ensureCurrentRequest(token, expectedTrackKey) {
  if (token !== requestToken || expectedTrackKey !== currentTrackKey) {
    throw new DOMException("Stale lyrics request", "AbortError");
  }
}

function cancelActiveRequest() {
  if (activeRequest) {
    activeRequest.abort();
    activeRequest = null;
  }
}

function readableError(error) {
  if (!navigator.onLine) {
    return "Murmur is offline. Reconnect and try again.";
  }
  return error?.message || "Murmur could not load lyrics for this track.";
}

function closeEmbeddedReader() {
  if (!embeddedReader) {
    return;
  }

  window.parent.postMessage({
    source: "murmur-reader",
    type: "MURMUR_CLOSE_INLINE_READER"
  }, "*");
}

function send(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(error);
        return;
      }
      if (response?.ok === false) {
        reject(new Error(response.error || "Murmur request failed"));
        return;
      }
      resolve(response || {});
    });
  });
}

window.addEventListener("unload", () => {
  cancelActiveRequest();
  if (refreshTimer) {
    window.clearInterval(refreshTimer);
  }
});
