(() => {
  function rankCandidates(track, candidates) {
    const deduped = new Map();
    for (const candidate of candidates) {
      if (candidate.url && !deduped.has(candidate.url)) {
        deduped.set(candidate.url, candidate);
      }
    }

    return [...deduped.values()]
      .map((candidate) => ({
        ...candidate,
        matchScore: scoreLyricsMatch(track, candidate)
      }))
      .filter((candidate) => Number.isFinite(candidate.matchScore))
      .sort((left, right) => right.matchScore - left.matchScore);
  }

  function selectBestCandidate(track, candidates) {
    const ranked = rankCandidates(track, candidates);
    if (ranked[0]) {
      return ranked[0];
    }

    const seen = new Set();
    return candidates.find((candidate) => {
      if (!candidate?.title || !candidate?.url || seen.has(candidate.url)) {
        return false;
      }
      seen.add(candidate.url);
      return true;
    }) || null;
  }

  function isGeniusSongHit(hit) {
    const result = hit?.result;
    if (!result) {
      return false;
    }
    return hit.type === "song" ||
      result.type === "song" ||
      /^\/songs\//i.test(result.api_path || "") ||
      /-lyrics\/?$/i.test(result.url || "");
  }

  function isExcludedLyricsElement(node) {
    const tagName = String(node?.tagName || "").toLowerCase();
    return Boolean(
      node?.hasAttribute?.("data-exclude-from-selection") ||
      node?.getAttribute?.("aria-hidden") === "true" ||
      ["script", "style", "button", "svg"].includes(tagName)
    );
  }

  function scoreLyricsMatch(target, candidate) {
    const targetTitle = normalizeWords(target.title);
    const candidateTitle = normalizeWords(candidate.title);
    const targetArtist = normalizeWords(target.artist);
    const candidateArtist = normalizeWords(candidate.artist);
    if (!targetTitle || !candidateTitle) {
      return Number.NEGATIVE_INFINITY;
    }

    const titleSimilarity = tokenSimilarity(targetTitle, candidateTitle);
    let titleScore = 0;
    if (targetTitle === candidateTitle) {
      titleScore = 100;
    } else if (titleSimilarity >= 0.8) {
      titleScore = 80;
    } else if (titleSimilarity >= 0.65) {
      titleScore = 65;
    } else {
      return Number.NEGATIVE_INFINITY;
    }

    let artistScore = 20;
    if (targetArtist) {
      if (targetArtist === candidateArtist) {
        artistScore = 70;
      } else if (candidateArtist.includes(targetArtist) || targetArtist.includes(candidateArtist)) {
        artistScore = 55;
      } else if (tokenSimilarity(targetArtist, candidateArtist) >= 0.6) {
        artistScore = 45;
      } else {
        return Number.NEGATIVE_INFINITY;
      }
    }

    const targetVersion = versionWords(target.title);
    const candidateVersion = versionWords(candidate.title);
    const unwantedVersion = [...candidateVersion].some((word) => !targetVersion.has(word));
    return titleScore + artistScore - (unwantedVersion ? 45 : 0);
  }

  function tokenSimilarity(leftValue, rightValue) {
    const left = new Set(leftValue.split(" ").filter(Boolean));
    const right = new Set(rightValue.split(" ").filter(Boolean));
    if (!left.size || !right.size) {
      return 0;
    }
    const intersection = [...left].filter((token) => right.has(token)).length;
    return intersection / Math.max(left.size, right.size);
  }

  function versionWords(value) {
    const matches = String(value || "").toLowerCase().match(/\b(remix|demo|live|acoustic|translation|translated|karaoke|cover|instrumental)\b/g);
    return new Set(matches || []);
  }

  function normalizeWords(value) {
    return String(value || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/\b(official|audio|video|lyrics?|visualizer)\b/g, " ")
      .replace(/\b(?:ft|feat|featuring)\.?\s+.*$/g, " ")
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeGeniusLyricsUrl(value) {
    try {
      const url = new URL(value || "", "https://genius.com");
      const allowedHost = url.hostname === "genius.com" || url.hostname === "www.genius.com";
      if (url.protocol !== "https:" || !allowedHost || !/-lyrics\/?$/i.test(url.pathname)) {
        return "";
      }
      url.hostname = "genius.com";
      url.search = "";
      url.hash = "";
      return url.toString();
    } catch (error) {
      return "";
    }
  }

  function normalizeLyricsText(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/\r/g, "")
      .replace(/[ \t]+/g, " ")
      .replace(/ *\n */g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function buildFallbackTrackKey(track) {
    return [normalizeWords(track?.artist), normalizeWords(track?.title)].filter(Boolean).join(":");
  }

  globalThis.MurmurLyricsCore = Object.freeze({
    buildFallbackTrackKey,
    isExcludedLyricsElement,
    isGeniusSongHit,
    normalizeGeniusLyricsUrl,
    normalizeLyricsText,
    normalizeWords,
    rankCandidates,
    selectBestCandidate,
    scoreLyricsMatch
  });
})();
