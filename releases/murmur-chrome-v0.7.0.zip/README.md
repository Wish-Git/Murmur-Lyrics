# Murmur for Chrome

This is the Chrome 114+ package. It includes Murmur's rounded controls popup and a native Chrome side panel that renders the best available Genius match in Murmur's own reader. Remote page HTML is never embedded in the panel.

## Load Unpacked

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked** and choose this `packages/chrome` folder.
4. Refresh any YouTube tabs that were already open.

The detection, matching, and reader code is shared with Opera GX. This Chrome package passes automated validation but has not yet been manually installed and tested in Chrome.
